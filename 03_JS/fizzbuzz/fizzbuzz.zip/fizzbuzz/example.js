// var x = 0;

// for(var i=1; i<5; i++){
//     x =+i
// }
// console.log(x);

// var x = "0";
// for(var i=1; i<5;i++){
//     x += i;
// }

// console.log(x);